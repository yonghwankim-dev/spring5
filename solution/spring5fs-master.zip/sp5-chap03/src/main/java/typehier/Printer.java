package typehier;

public interface Printer {
	void print(String msg);
}
