package chap07;

public interface Calculator {

	public long factorial(long num);

}
