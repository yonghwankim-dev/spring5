package sp5.sp5chapcboot.spring;

public class MemberNotFoundException extends RuntimeException {

}
